export class Message {
    clientuniqueid: string;
    type: string;
    message: string;
    date: Date;
    ProductId:number;
    ProductVariantDetailId:number;
    CustomerId:number;
    VendorId:number;
    IpAddress:string;
    VendorMsg:string;
    CustomerMsg:string;
    ProductImage:string;

  }